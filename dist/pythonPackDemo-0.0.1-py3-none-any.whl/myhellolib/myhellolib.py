def greeter(s):
    print(s.upper())